import bcrypt from "bcrypt";
import { User, sequelize } from "../models/userModel.js";

await sequelize.sync();

export const loginPage = (req, res) => {
  res.render("login", { title: "Login" });
};

export const registerPage = (req, res) => {
  res.render("register", { title: "Register" });
};

export const forgotPasswordPage = (req, res) => {
  res.render("forgotpassword", { title: "Forgot Password" });
};

export const dashboardPage = async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  try {
    const users = await User.findAll({
      attributes: ["id", "name", "email"]
    });

    res.render("dashboard", {
      title: "Dashboard",
      users
    });
  } catch (error) {
    console.error(error);
    res.status(500).send("Unable to load user records.");
  }
};

export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.send("User not found");
    }

    const match = await bcrypt.compare(password, user.password);

    if (!match) {
      return res.send("Incorrect password");
    }

    req.session.userId = user.id;
    res.redirect("/dashboard");
  } catch (error) {
    console.error(error);
    res.status(500).send("Login failed.");
  }
};

export const registerUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const hashed = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      email,
      password: hashed
    });

    req.session.userId = user.id;
    res.redirect("/dashboard");
  } catch (error) {
    console.error(error);
    res.status(500).send("Registration failed.");
  }
};

export const logoutUser = (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
};