import bcrypt from "bcrypt";
import { User } from "../models/userModel.js";

export const addUserPage = (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  res.render("adduser", { title: "Add User" });
};

export const createUser = async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  try {
    const { name, email, password } = req.body;

    const existingUser = await User.findOne({ where: { email } });

    if (existingUser) {
      return res.status(400).send(
        'Email already exists. <a href="/users/add">Go back</a>'
      );
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    await User.create({
      name,
      email,
      password: hashedPassword
    });

    res.redirect("/dashboard");
  } catch (error) {
    console.error(error);
    res.status(500).send("Unable to add user.");
  }
};

export const editUserPage = async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  try {
    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).send("User not found.");
    }

    res.render("edituser", {
      title: "Edit User",
      user
    });
  } catch (error) {
    console.error(error);
    res.status(500).send("Unable to load user.");
  }
};

export const updateUserView = async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  try {
    const { name, email, password } = req.body;
    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).send("User not found.");
    }

    const existingUser = await User.findOne({ where: { email } });

    if (existingUser && existingUser.id !== user.id) {
      return res.status(400).send(
        'Email already exists. <a href="/users/' + user.id + '/edit">Go back</a>'
      );
    }

    const updates = { name, email };

    if (password && password.trim() !== "") {
      updates.password = await bcrypt.hash(password, 10);
    }

    await user.update(updates);

    res.redirect("/dashboard");
  } catch (error) {
    console.error(error);
    res.status(500).send("Unable to update user.");
  }
};

export const deleteUserView = async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  try {
    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).send("User not found.");
    }

    if (Number(req.params.id) === Number(req.session.userId)) {
      return res.status(400).send(
        'You cannot delete your own logged-in account. <a href="/dashboard">Go back</a>'
      );
    }

    await user.destroy();

    res.redirect("/dashboard");
  } catch (error) {
    console.error(error);
    res.status(500).send("Unable to delete user.");
  }
};