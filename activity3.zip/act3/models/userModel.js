import { DataTypes } from "sequelize";
import { sequelize } from "./db.js";

export const User = sequelize.define("User", {
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

// INSERT
export async function insert(data) {
  return await User.create(data);
}

// SELECT ALL
export async function all() {
  return await User.findAll({
    attributes: ["id", "name", "email", "createdAt", "updatedAt"]
  });
}

// SELECT BY ID
export async function one(id) {
  return await User.findByPk(id, {
    attributes: ["id", "name", "email", "createdAt", "updatedAt"]
  });
}

// UPDATE
export async function update(id, data) {
  const user = await User.findByPk(id);

  if (!user) {
    return null;
  }

  await user.update(data);

  return user;
}

// DELETE
export async function remove(id) {
  const user = await User.findByPk(id);

  if (!user) {
    return null;
  }

  await user.destroy();

  return user;
}

export { sequelize };