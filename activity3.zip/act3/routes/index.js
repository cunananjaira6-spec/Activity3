import express from "express";

import { homePage } from "../controllers/homeController.js";

import {
  loginPage,
  registerPage,
  forgotPasswordPage,
  dashboardPage,
  loginUser,
  registerUser,
  logoutUser
} from "../controllers/authController.js";

import {
  insertUser,
  allUsers,
  oneUser,
  updateUser,
  deleteUser
} from "../controllers/userController.js";

import {
  addUserPage,
  createUser,
  editUserPage,
  updateUserView,
  deleteUserView
} from "../controllers/userViewController.js";

const router = express.Router();

// Home
router.get("/", homePage);

// Login and Register
router.get("/login", loginPage);
router.post("/login", loginUser);

router.get("/register", registerPage);
router.post("/register", registerUser);

router.get("/forgot-password", forgotPasswordPage);
router.get("/dashboard", dashboardPage);
router.get("/logout", logoutUser);

// View CRUD routes
router.get("/users/add", addUserPage);
router.post("/users/add", createUser);

router.get("/users/:id/edit", editUserPage);
router.post("/users/:id/edit", updateUserView);

router.post("/users/:id/delete", deleteUserView);

// Postman API CRUD routes
router.post("/users", insertUser);
router.get("/users", allUsers);
router.get("/users/:id", oneUser);
router.put("/users/:id", updateUser);
router.delete("/users/:id", deleteUser);

export default router;